﻿# Copyright 2024 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

<#
  .SYNOPSIS
    Gather Diagnostic Data for Application Database Connection

  .DESCRIPTION
    This script was written to gather various attributes from the Application to confirm
    connectivity to the Database Server in the Connection String.
#>

##### Script Error Behavior #####

$ErrorActionPreference = “silentlycontinue”

##### Functions #####

function Get-TimeStamp ($ScriptExecutionPosition="default") {
    $Timestamp = Get-Date -Format "MM-dd-yyyy-HH:mm:ss"
    switch ($ScriptExecutionPosition) {
        "Start" {
            Log-Message -LogType "Info" -Message "Starting script execution at $Timestamp"  
        }
        "End" {
            Log-Message -LogType "Info" -Message "Script execution complete at $Timestamp"  
        }
        "default" {
            Log-Message -LogType "Info" -Message "Timestamp: $Timestamp"
        }
    }
}

function Log-Message ($LogType, $Message, $NoExtraLine) {
    switch ($LogType) {
        "BannerStart" {
            Write-Output "*****    D A T A B A S E   D I A G N O S T I C S    *****"
            Log-Message -LogType "EmptyLine" -NoExtraLine $NoExtraLine
        }
        "BannerEnd" {
            Write-Output "*****      E N D   O F   D I A G N O S T I C S      *****"
            Log-Message -LogType "EmptyLine" -NoExtraLine $NoExtraLine
        }
        "EmptyLine" {
            If (($NoExtraLine -eq $FALSE) -or (!$NoExtraLine)) {
                Write-Output ""
            }
        }
        "NoTag" {
            Write-Output "        $Message"
            Log-Message -LogType "EmptyLine" -NoExtraLine $NoExtraLine
        }
        "Info" {
            Write-Output "[INFO]  $Message"
            Log-Message -LogType "EmptyLine" -NoExtraLine $NoExtraLine
        }
        "Error" {
            Write-Output "[ERROR] $Message"
            Log-Message -LogType "EmptyLine" -NoExtraLine $NoExtraLine
        }
        "Term" {
            Write-Output "[TERM]  Exiting"
            Log-Message -LogType "EmptyLine" -NoExtraLine $NoExtraLine
            Log-Message -LogType "End"
        }
        "default" {
            Write-Output "        $Message"
        }
    }
}

function Get-ConnectionString {
    
    Import-Module WebAdministratio
    $SitePath = (Get-Website).PhysicalPath.Replace("%SystemDrive%","$Env:SystemDrive")
    $ConnectionString = ([xml](Get-Content -LiteralPath $SitePath\Web.config)).configuration.connectionStrings.add.connectionString
    $SQLConnectionStringBuilder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder -argumentlist $ConnectionString

    If (($SQLConnectionStringBuilder["Data Source"]).Contains(",")) {
        $SQLDatabaseServer = ($SQLConnectionStringBuilder["Data Source"] -Split ",")[0]
        $SQLDatabaseServerPort = ($SQLConnectionStringBuilder["Data Source"] -Split ",")[1]
    } Else {
        $SQLDatabaseServer = $SQLConnectionStringBuilder["Data Source"]
        $SQLDatabaseServerPort = 1433
    }

    $SQLDatabase = $SQLConnectionStringBuilder["Initial Catalog"]
    $Security = $SQLConnectionStringBuilder["Integrated Security"]
    $MultiSubnetFailover = $SQLConnectionStringBuilder["MultiSubnetFailover"]

    Log-Message -LogType "Info" -Message "Connection String" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "-----------------" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Data Source         : $SQLDatabaseServer" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Data Source Port    : $SQLDatabaseServerPort" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Database Name       : $SQLDatabase" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Integrated Security : $Security" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "MultiSubnetFailover : $MultiSubnetFailover"

    Log-Message -LogType "Info" -Message "Resolving DNS for $SQLDatabaseServer"
    
    Get-ListenerIPs -DatabaseServer $SQLDatabaseServer
    Log-Message -LogType "Info" -Message "Testing connectivity to $SQLDatabaseServer"
    
    Test-DatabaseConnection -DatabaseServer $SQLDatabaseServer -DatabaseServerPort $SQLDatabaseServerPort
}

function Get-ListenerIPs ($DatabaseServer) {
    $ListenerIP = Resolve-DnsName $DatabaseServer
    Log-Message -LogType "Info" -Message "Listener IPs" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "------------" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message ($ListenerIP | Format-Table -AutoSize | Out-String).TrimEnd()
}


function Test-DatabaseConnection ($DatabaseServer, $DatabaseServerPort) {
    $NetConnTest = Test-NetConnection $DatabaseServer -Port $DatabaseServerPort
    $SourceIP = $NetConnTest.SourceAddress.IPAddress
    $DestinationIP = $NetConnTest.RemoteAddress.IPAddressToString
    $DestinationPort = $NetConnTest.RemotePort
    $TestSuccessful = $NetConnTest.TcpTestSucceeded

    Log-Message -LogType "Info" -Message "Network Connection Test" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "-----------------------" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Source IP        : $SourceIP" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Destination IP   : $DestinationIP" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Destination Port : $DestinationPort" -NoExtraLine $TRUE
    Log-Message -LogType "NoTag" -Message "Test Successful  : $TestSuccessful"
    
    
}


##### Main #####

Log-Message -LogType "BannerStart"
Get-Timestamp -ScriptExecutionPosition "Start"
Get-ConnectionString
Get-Timestamp -ScriptExecutionPosition "End"
Log-Message -LogType "BannerEnd"